#!/bin/bash
# 传递到脚本的参数个数
counter=$#

kubectl get namespace --all-namespaces
