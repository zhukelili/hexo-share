#!/bin/bash
# 传递到脚本的参数个数
counter=$#

kubectl create namespace $1
