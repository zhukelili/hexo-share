#!/bin/bash

isContinue(){

echo "[y/n]"

read sti

if [ "y" != ${sti} ]
then
    exit
fi
	
}
