#!/bin/bdfash
source common/common.sh
echo "示例：kubectl describe deployment memory-demo-3 --namespace=mem-example"
#

# 传递到脚本的参数个数
counter=$#

echo "deployment名称：$1"

echo "命令空间：$2"

kubectl describe deployment $1 --namespace=$2
