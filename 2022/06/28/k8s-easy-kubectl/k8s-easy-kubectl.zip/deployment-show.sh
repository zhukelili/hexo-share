#!/bin/bdfash
source common/common.sh
echo "示例：kubectl get deployments --namespace=test"
#

# 传递到脚本的参数个数
counter=$#

echo "命令空间：$1"

kubectl get deployments --namespace=$1
