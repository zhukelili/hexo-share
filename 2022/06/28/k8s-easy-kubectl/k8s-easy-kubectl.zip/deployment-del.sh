#!/bin/bash
source common/common.sh
echo "示例："
echo ' kubectl delete deployment nginx-deployment'

#
isContinue

# 传递到脚本的参数个数
counter=$#

kubectl delete deployment $1 --namespace=$2
