#!/bin/bash
source common/common.sh
echo "示例："
echo '- kubectl delete namespace mem-example'

#
isContinue

# 传递到脚本的参数个数
counter=$#

kubectl delete namespace $1
