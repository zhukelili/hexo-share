#!/bin/bin
source common/common.sh
echo "示例：kubectl describe pod memory-demo-3 --namespace=mem-example"


echo "pod名称：$1"

echo "命令空间：$2"

kubectl describe pod $1 --namespace=$2
