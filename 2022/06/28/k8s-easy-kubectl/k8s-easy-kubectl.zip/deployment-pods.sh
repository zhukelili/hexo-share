#!/bin/bdfash
source common/common.sh
echo "示例：列出该Deployment创建的Pod"
echo "- kubectl get pods -l app=nginx"

# 传递到脚本的参数个数
counter=$#

echo "标签名称：$1"


kubectl get pods -l $1 --namespace=$2
