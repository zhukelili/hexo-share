#!/bin/bash
source common/common.sh
echo "示例："
echo '- kubectl apply -f https://k8s.io/examples/application/deployment.yaml'
echo '- kubectl apply -f https://k8s.io/examples/pods/resource/memory-request-limit.yaml --namespace=mem-example'

# 
isContinue

# 传递到脚本的参数个数
counter=$#

echo "yaml名称：$1"

echo "命令空间：$2"


kubectl apply -f $1 --namespace=$2


deployment-pods.sh 
